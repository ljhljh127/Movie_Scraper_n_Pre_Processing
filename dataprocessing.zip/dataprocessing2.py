import os,sys
import pandas as pd
from openpyxl import load_workbook
path="C:/Users/이정현/PycharmProjects/pythonProject/dataprocessing/영화"
count=0
file_list = os.listdir(path)

for file_name_raw in file_list:
    file_name="C:/Users/이정현/PycharmProjects/pythonProject/dataprocessing/영화/"+file_name_raw
    file_date="C:/Users/이정현/PycharmProjects/pythonProject/dataprocessing/영화 날짜/영화 날짜 파일.xlsx"
    df_file_date = pd.read_excel(file_date,engine='openpyxl')
    df = pd.read_excel(file_name,engine='openpyxl')
    date = df_file_date.iloc[count,1]
    print(file_name_raw)
    movie_date_list = df[df["날짜"]>=date].iloc[0:10,:]
    print(movie_date_list)
    print(movie_date_list["스크린수"].max())
    print(movie_date_list["상영횟수"].mean())
    print(movie_date_list["상영점유율"].mean())
    print(movie_date_list["좌석수"].mean())
    print(movie_date_list["관객수"].mean())
    print(movie_date_list["누적관객수"].max())
    movie_date_list.set_index('날짜',inplace=True)
    df1={
        "이름" :[]
    }
    for i in movie_date_list.values:
        df1[i]=list()
    df1
    count += 1
    sys.exit()

